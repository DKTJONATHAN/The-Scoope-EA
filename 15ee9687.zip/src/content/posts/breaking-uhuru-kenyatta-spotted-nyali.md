---
title: "BREAKING: Uhuru Kenyatta Spotted at Nyali Beach with Mystery Woman"
description: "Former President Uhuru Kenyatta was seen enjoying a quiet afternoon at Nyali Beach in Mombasa with an unidentified woman, sparking rumors across social media."
pubDate: 2025-09-17
author: "Jonathan Mwaniki"
category: "Celebrity"
tags: ["uhuru", "politics", "mombasa", "celebrity"]
image: "https://images.unsplash.com/photo-1542272605-0a153f6c0c82?auto=format&fit=crop&w=900&q=80"
slug: "breaking-uhuru-kenyatta-spotted-nyali"
readTime: "2 min read"
---

## Former President's Surprise Mombasa Getaway

Former President Uhuru Kenyatta was photographed yesterday afternoon at the exclusive Nyali Beach resort in Mombasa, accompanied by a woman whose identity remains unknown. The sighting has set Kenyan social media ablaze with speculation about the nature of their relationship.

![Eyewitness](https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=750&q=80)

Multiple sources at the beach resort confirmed that the former Head of State appeared relaxed and in good spirits during his visit.

### Social Media Reactions

The photos, which quickly went viral on Twitter and Instagram, have generated thousands of comments and shares. Many Kenyans are curious about this mysterious companion.

### Political Implications

While Uhuru has largely stayed out of the public eye since leaving office, this appearance comes at a time when his political future remains a subject of speculation.