---
title: "Diana Marua Pregnancy Rumors Explode After Cryptic Social Media Post"
description: "Bahati's wife Diana Marua has set tongues wagging after posting a mysterious photo that has fans convinced she might be expecting baby number three."
pubDate: 2025-09-16
author: "Jonathan Mwaniki"
category: "Gossip"
tags: ["diana-marua", "bahati", "pregnancy", "social-media"]
image: "https://images.unsplash.com/photo-1465101162946-4377e57745c3?auto=format&fit=crop&w=900&q=80"
slug: "diana-marua-pregnancy-rumors-social-media"
readTime: "3 min read"
---

## The Post That Started It All

Diana Marua, wife to popular musician Bahati, has sparked pregnancy speculation after sharing what fans interpret as a "baby bump" photo.

![Diana Marua Viral](https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=750&q=80)

### Fan Reactions Pour In

Within hours, Diana's comments section was flooded with congratulatory messages and pregnancy-related emojis.

### The Bahati Family Dynamic

If true, this would be the third child for the couple, making this rumor believable to their fanbase.

### What's Next?

Sources suggest an official announcement could come at Bahati's Nairobi performance.